/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#ifndef __SPRITE_H__
#define __SPRITE_H__

#include "ObjBase.h"

class Sprite : public ObjBase {
  protected:

  bool m_isDestroyed;

  public:

  Sprite() : m_isDestroyed(false) {}

  Sprite(const Sint16 x, const Sint16 y, const Uint16 w, const Uint16 h,
         const Uint8 r, const Uint8 g, const Uint8 b,
         const SDL_Surface* pSurface)
    : ObjBase(x, y, w, h, r, g, b, pSurface),
    m_isDestroyed(false) {}

  // Use the default C++ destructor
  virtual ~Sprite() {}

  inline bool isDestroyed(void) const { return m_isDestroyed; }

  virtual void destroy(void) { m_isDestroyed = true; }

  virtual bool draw(const SDL_Surface* pSurface) const;

}; // Sprite{}

#endif // #ifndef __SPRITE_H__
