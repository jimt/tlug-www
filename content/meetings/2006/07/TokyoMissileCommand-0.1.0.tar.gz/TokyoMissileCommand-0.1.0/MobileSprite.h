/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#ifndef __MOBILESPRITE_H__
#define __MOBILESPRITE_H__

#include "Sprite.h"

class MobileSprite : public Sprite {
  protected:

  Sint16 m_dx;    // total change in x (for the present vector)
  Sint16 m_dy;    // total change in y (for the present vector)
  Sint16 m_speed; // move dx/speed and dy/speed units every iteration

  Sint16 m_xRemainder; // remainder from dx/speed division
  Sint16 m_yRemainder; // remainder from dy/speed division

  Sint16 m_lastX; // last x position
  Sint16 m_lastY; // last y position

  Sint16 m_minX; // minumum legal x position
  Sint16 m_maxX; // maximum legal x position
  Sint16 m_minY; // minumum legal y position
  Sint16 m_maxY; // maximum legal y position

  public:

  MobileSprite() : m_dx(0), m_dy(0), m_speed(0), m_xRemainder(0),
    m_yRemainder(0), m_lastX(0), m_lastY(0), m_minX(0), m_maxX(0),
    m_minY(0), m_maxY(0) {}

  MobileSprite(const Sint16 x, const Sint16 y, const Uint16 w, const Uint16 h,
               const Uint8 r, const Uint8 g, const Uint8 b,
               const SDL_Surface* pSurface,
               const Sint16 dx, const Sint16 dy, const Sint16 speed,
               const Sint16 minX, const Sint16 maxX,
               const Sint16 minY, const Sint16 maxY)
    : Sprite(x, y, w, h, r, g, b, pSurface), m_dx(dx), m_dy(dy),
    m_speed(speed), m_xRemainder(0), m_yRemainder(0),
    m_minX(minX), m_maxX(maxX), m_minY(minY), m_maxY(maxY) {
    m_lastX = getX();
    m_lastY = getY();
  } // MobileSprite()

  // Use the default C++ destructor
  virtual ~MobileSprite() {}

  virtual int getDX(void)    const { return m_dx;    }
  virtual int getDY(void)    const { return m_dy;    }
  virtual int getSpeed(void) const { return m_speed; }

  virtual void setDX(const int dx)       { m_dx    = dx;    }
  virtual void setDY(const int dy)       { m_dy    = dy;    }
  virtual void setSpeed(const int speed) { m_speed = speed; }

  virtual void move(void);

}; // MobileSprite{}

#endif // #ifndef __MOBILESPRITE_H__
