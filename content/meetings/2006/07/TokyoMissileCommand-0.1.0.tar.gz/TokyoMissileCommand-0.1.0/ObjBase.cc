/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#include "ObjBase.h"

void ObjBase::setColour(const Uint8 r, const Uint8 g, const Uint8 b,
                        const SDL_Surface* pSurface) {
  if (pSurface == NULL) return;

  m_col = SDL_MapRGB(pSurface->format, r, g, b);
} // ObjBase::setColour()
