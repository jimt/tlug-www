/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#ifndef __MISSILE_H__
#define __MISSILE_H__

#include "MobileSprite.h"

class Missile : public MobileSprite {
  protected:
  static const Sint16 MAX_EXPLOSION_RADIUS = 24;

  Sint16 m_explosionRadius;

  Sprite* m_pTarget; // sprite that will be destroyed when we explode

  // Hack for SDL_gfx library's crappy colour format
  SDL_Color m_unmappedColour;

  public:

  // Constants
  static const Uint16 WIDTH  = 2;
  static const Uint16 HEIGHT = 2;

  Missile() : m_explosionRadius(0) {
    m_unmappedColour.r = 0;
    m_unmappedColour.g = 0;
    m_unmappedColour.b = 0;

    setW(WIDTH);
    setH(HEIGHT);
  } // Missile()

  Missile(const Sint16 x, const Sint16 y,
          const Uint8 r, const Uint8 g, const Uint8 b,
          const SDL_Surface* pSurface,
          const Sint16 dx, const Sint16 dy, const Sint16 speed,
          const Sint16 minX, const Sint16 maxX,
          const Sint16 minY, const Sint16 maxY)
    : MobileSprite(x, y, WIDTH, HEIGHT, r, g, b, pSurface, dx, dy, speed,
                   minX, maxX, minY, maxY),
    m_explosionRadius(0) {
    m_unmappedColour.r = r;
    m_unmappedColour.g = g;
    m_unmappedColour.b = b;
  } // Missile()

  // Use the default C++ destructor
  virtual ~Missile() {}

  inline Sprite* getTarget(void) const { return m_pTarget; }

  // Our version of draw() must handle explosions!
  bool draw(const SDL_Surface* pSurface) const;

  // Our version of move() must handle collision detection
  void move(void);
  
  void explode(void);

  inline void setTarget(Sprite* pSprite) { m_pTarget = pSprite; }

}; // Missile{}

#endif // #ifndef __MISSILE_H__
