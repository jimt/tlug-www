#ifndef __CITY_H__
#define __CITY_H__

#include "Building.h"

class City : public Building {
  public:

  // Constants
  static const Uint16 WIDTH  = 32;
  static const Uint16 HEIGHT = 8;

  City() {
    setW(WIDTH);
    setH(HEIGHT);
  } // City()

  City(const Sint16 x, const Sint16 y,
       const Uint8 r, const Uint8 g, const Uint8 b,
       const SDL_Surface* pSurface)
    : Building(x, y, WIDTH, HEIGHT, r, g, b, pSurface) {}

  // Use the default C++ destructor
  virtual ~City() {}

}; // City{}

#endif // #ifndef __CITY_H__
