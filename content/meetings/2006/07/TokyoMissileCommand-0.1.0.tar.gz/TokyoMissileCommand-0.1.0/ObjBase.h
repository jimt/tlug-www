/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#ifndef __OBJBASE_H__
#define __OBJBASE_H__

#include "SDL.h"

class ObjBase {
  protected:

  SDL_Rect m_pos; // current position
  Uint32   m_col; // colour

  public:

  ObjBase() : m_col(0) {
    m_pos.x = 0;
    m_pos.y = 0;
    m_pos.w = 0;
    m_pos.h = 0;
  } // ObjBase()

  ObjBase(const Sint16 x, const Sint16 y, const Uint16 w, const Uint16 h,
          const Uint8 r, const Uint8 g, const Uint8 b,
          const SDL_Surface* pSurface) {
    m_pos.x = x;
    m_pos.y = y;
    m_pos.w = w;
    m_pos.h = h;

    setColour(r, g, b, pSurface);
  } // ObjBase()

  // Use the default C++ copy constructor
  // ObjBase(const ObjBase& rhs);

  // Use the default C++ destructor
  virtual ~ObjBase() {}

  // Use the default C++ assignment operator
  // ObjBase& operator= (const ObjBase& rhs);

  inline Sint16 getX(void) const { return m_pos.x; }
  inline Sint16 getY(void) const { return m_pos.y; }
  inline Uint16 getW(void) const { return m_pos.w; }
  inline Uint16 getH(void) const { return m_pos.h; }

  inline SDL_Rect getPos(void)    const { return m_pos; }
  inline Uint32   getColour(void) const { return m_col; }

  inline void setX(const Sint16 x) { m_pos.x = x; }
  inline void setY(const Sint16 y) { m_pos.y = y; }

  virtual void setW(const Uint16 w) { m_pos.w = w; }
  virtual void setH(const Uint16 h) { m_pos.h = h; }

  virtual void setColour(const Uint8 r, const Uint8 g, const Uint8 b,
                         const SDL_Surface* pSurface);

  virtual bool draw(const SDL_Surface* pSurface) const = 0;

}; // ObjBase{}

#endif // #ifndef __OBJBASE_H__
