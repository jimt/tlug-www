/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#include <stdlib.h>

#include "MobileSprite.h"

void MobileSprite::move(void) {
  Sint16 speed = getSpeed();

  // If the speed is 0, just return
  if (speed == 0) return;

  m_lastX = getX();
  m_lastY = getY();

  Sint16 x = m_lastX + (getDX() / speed);
  Sint16 y = m_lastY + (getDY() / speed);

  m_xRemainder += abs(getDX() % speed);
  m_yRemainder += abs(getDY() % speed);

  if (m_xRemainder >= speed) {
    x += 1 * (getDX() > 0 ? 1 : -1);
    m_xRemainder -= speed;
  } // if (x remainder has rolled over)

  if (m_yRemainder >= speed) {
    y += 1 * (getDY() > 0 ? 1 : -1);
    m_yRemainder -= speed;
  } // if (y remainder has rolled over)

  setX(x);
  setY(y);
} // MobileSprite::move()
