/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#ifndef __MISSILELAUNCHER_H__
#define __MISSILELAUNCHER_H__

#include "Building.h"

class MissileLauncher : public Building {
  public:

  // Constants
  static const Uint16 WIDTH  = 8;
  static const Uint16 HEIGHT = 32;

  MissileLauncher() {
    setW(WIDTH);
    setH(HEIGHT);
  } // MissileLauncher()

  MissileLauncher(const Sint16 x, const Sint16 y,
                  const Uint8 r, const Uint8 g, const Uint8 b,
                  const SDL_Surface* pSurface)
    : Building(x, y, WIDTH, HEIGHT, r, g, b, pSurface) {}

  // Use the default C++ destructor
  virtual ~MissileLauncher() {}

}; // MissileLauncher{}

#endif // #ifndef __MISSILELAUNCHER_H__
