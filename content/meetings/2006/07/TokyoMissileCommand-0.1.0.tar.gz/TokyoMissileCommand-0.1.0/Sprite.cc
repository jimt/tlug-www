/* =========================================================================
 * Copyright (c) 2006 and onwards, Josh Glover <jmglov@jmglov.net>,
 * Robert Ota Dieterich <otanobunaga@gmail.com>
 *
 * LICENCE:
 *
 *   This file is distributed under the terms of the BSD-2 License.
 *   See the COPYING file, which should have been distributed with
 *   this file, for details. If you did not receive the COPYING file,
 *   see:
 *
 *   http://www.jmglov.net/opensource/licenses/bsd.txt
 */

#include "Sprite.h"

bool Sprite::draw(const SDL_Surface* pSurface) const {
  // If this sprite has been destroyed, just return
  if (isDestroyed()) return true;

  if (SDL_FillRect(const_cast<SDL_Surface*>(pSurface),
                   const_cast<SDL_Rect*>(&m_pos), m_col) == -1) {
      return false;
  } // if (SDL_FillRect() failed)

  return true;
} // Sprite::draw()
